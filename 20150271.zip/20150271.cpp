#include <iostream>

using namespace std;//std::를 생략하기 위해

void div(int&, int&);

int main(void){
	int num1, num2;
	cout<<"나눌 값을 입력하시오 : ";
	cin>>num1;//나눌 값 입력
	cout<<"나누고자 하는 값을 입력하시오 : ";
	cin>>num2;//나누고자 하는 값 입력
	try{//예외처리
		if(num2 == 0)//나누고자 하는 값이 0일 경우num2를 catch문으로 던짐
			throw num2;
		div(num1, num2);//나누고자 하는 값이 0이 아닐 경우
	}
	catch(int zero)
	{
		cout<<"제수는 "<<zero<<"이 될 수 없습니다."<<endl;
		cout<<"프로그램을 다시 실행하세요."<<endl;
	}
	return 0;
}

void div(int& number1, int& number2){//참조자로 나누고 출력하는 함수
	int quo, remain;
	quo = number1/number2;
	remain = number1%number2;
	cout<<"나눗셈의 몫 : "<<quo<<""<<endl;
	cout<<"나눗셈의 나머지 : "<<remain<<""<<endl;
}
